/* 2018CSZ0002 B SatyaJaswanth */
import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

public class Insert {

	static ArrayList array = new ArrayList();
		
	public static void main(String[] args) {
		
		Scanner sn = new Scanner(System.in);		
		//System.out.println("Select The Operation(1 0r 2):");
		String operation = "";
			
		do{
			System.out.println("Select The Operation(1 0r 2):");
			operation = sn.next();
			   } while( !isvalids(operation));
		
		
		if(operation.equals("2")){
			String cname = "";
			System.out.println("Select Query(1, 2, or 3):");
			int query = sn.nextInt();
			if(query==3){
				System.out.println("Enter Country Name:");
				cname = sn.next();
			}else{
			System.out.println("Enter Calss Name:");
			cname = sn.next();
			}
			
			retrieve(query, cname);	
			
		}
		
		
		if(operation.equals("1")){
			
		array.clear();
		
		String table = "";
		
		do{
		System.out.println("Enter Table Name:");
		table = sn.next();
		}while(!isvalidt(table));
		
		System.out.println("Enter Number of Records:");
		int record = sn.nextInt();
		String name = "";
		
		for(int i=0;i<record;i++){
			
		if(table.equals("classes")){
			
			do{
				System.out.println("Enter Class Name:");
				      name = sn.next();
				   } while( !isValidp(name, "Class", table));
			
			System.out.println("Enter Type Name");
			array.add(sn.next());
			System.out.println("Enter Country Name:");			
			array.add(sn.next());
			
			do{
				System.out.println("Enter NumGuns Name:");
				      name = sn.next();
				   } while( !isValid(name) );
						
		
			do{
				System.out.println("Enter Bore Name:");
				      name = sn.next();
				   } while( !isValid(name) );
			
			do{
				System.out.println("Enter Displacement Name:");
				      name = sn.next();
				   } while( !isValid(name) );
			
			
		}
		
		if(table.equals("ships")){
					
			do{
				System.out.println("Enter Ship Name:");
				      name = sn.next();
				   } while( !isValidp(name, "Name", table));
			
			
			System.out.println("Enter Class Name:");		
			array.add(sn.next());			
			do{
				System.out.println("Enter Year:");
				      name = sn.next();
				   } while( !isValidY(name) );
			
			
		}
		
		if(table.equals("battles")){
			
			do{
				System.out.println("Enter Battle Name:");
				      name = sn.next();
				   } while( !isValidp(name, "Name", table));
			
			
			do{
				System.out.println("Enter Year:");
				      name = sn.next();
				   } while( !isValidY(name) );
			
		}
		
		
		if(table.equals("outcomes")){
			
			System.out.println("Enter Ship Name:");			
			array.add(sn.next());
			System.out.println("Enter Battle Name:");		
			array.add(sn.next());
			System.out.println("Enter Result");		
			array.add(sn.next());
			
		}
		
		}
		
		insql(array, table);
		
		}

	}
	
	private static boolean isvalids(String table) {
		
		String[] arr = {"1", "2"};
		
		ArrayList array = new ArrayList();
		for(int i=0;i<arr.length;i++){
			array.add(arr[i].toLowerCase());
		}
		
		if(array.contains(table.toLowerCase())){
			return true;
		}else{
			System.out.println("Please Choose Correct one");
		       return false;			
		}
		
	}
	
	private static boolean isvalidt(String table) {
		
		String[] arr = {"classes", "battles", "outcomes", "ships"};
		
		ArrayList array = new ArrayList();
		for(int i=0;i<arr.length;i++){
			array.add(arr[i].toLowerCase());
		}
		
		if(array.contains(table.toLowerCase())){
			return true;
		}else{
			System.out.println("Enter Correct Table Name");
		       return false;			
		}
		
	}


	private static boolean isValidp(String name, String col, String table) {
		
		ArrayList ar = new ArrayList();
		ar = recol(col, table);
		if(ar.contains(name.toLowerCase())){
			System.out.println("Enter Another Name. Already Exist");
		       return false;
		   }  else {
			   array.add(name);
			   return true;
		   }		
		
	}

	private static Connection config(){
		
		Connection con = null;
		
		try{
			
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment", "root", "root");
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return con;
		
	}

	private static ArrayList recol(String col, String table) {
		
		ArrayList array1 = new ArrayList();
		
		try{	
			
			Connection con = config();
			PreparedStatement ps = con.prepareStatement("select "+col+" from "+table+"");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				array1.add(rs.getString(1).toLowerCase());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return array1;
	}


	private static boolean isValidY(String name) {
		if(name.length()!=4){	
			   System.out.println("Enter Four Digits Only");
		       return false;
		   }  else {
			   array.add(name);
			   return true;
		   }
	}
	

	private static boolean isValid(String name){
		   if(Pattern.matches("[a-z A-Z]*",name)){	
			   System.out.println("Enter Integers Only");
		       return false;
		   }  else {
			   array.add(name);
			   return true;
		   }
		}
	
	

	private static void retrieve(int query, String input) {
		
		String sql = "";
		
		if(query==1){
			sql = "select Name, Year from battles where Name IN(select Battle from outcomes where Ship IN(select Name from ships where Class IN(select Class from classes where Class='"+input+"')) and Result='Sunk')";
			re(sql, 2);
			
		}
		
		if(query==2){
			sql= "select MIN(Year) from Ships where Class IN(select Class from classes where Class='"+input+"') limit 1";
			re(sql, 1);
		}
		
		if(query==3){
			
			sql ="select Ship from outcomes where Ship IN(select Name from ships where Class IN(select Class from classes where Country='"+input+"')) and (Result='OK' OR Result='Damaged')";
			re(sql, 1);
		}
		
	}

	private static void re(String sql, int i) {
		
		StringBuilder sb = new StringBuilder();
		//String result = "";
				
		if(i==2){
		
		try{			
			Connection con = config();
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				
				sb.append(rs.getString(1)+","+rs.getString(2)+"\n");
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		}else{
			
			try{			
				Connection con = config();
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
					
					sb.append(rs.getString(1)+"\n");	
					
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		if(sb.length()==0){
			System.out.println("No Records Matching");
		}else{
			System.out.println(sb);
		}
		
		
		
	}

	private static void insql(ArrayList array, String table) {
		
		String sql = "";
		
		if(table.equals("classes")){
			sql = "insert into classes(Class, Type, Country, numGuns, bore, Displacement)values(?, ?, ?, ?, ?, ?)";
			dbconn(array, 6, sql);
		}
		
		if(table.equals("ships")){
			sql = "insert into ships(Name, Class, Year)values(?, ?, ?)";
			dbconn(array, 3, sql);
		}
		
		if(table.equals("battles")){
			sql = "insert into battles(Name, Year)values(?, ?)";
			dbconn(array, 2, sql);
		}
		
		if(table.equals("outcomes")){
			sql = "insert into outcomes(Ship, Battle, Result)values(?, ?, ?)";
			dbconn(array, 3, sql);
		}
		
	}
	
	private static void dbconn(ArrayList array, int col, String sql) {
		
		int count = 0;
		
		for(int j=0;j<array.size();j+=col){
			
			List list = array.subList(j, j+col);
			
			try{			
				Connection con = config();
				PreparedStatement ps = con.prepareStatement(sql);
				for(int i=0;i<list.size();i++){
				ps.setString(i+1, list.get(i).toString());
				}
				count = ps.executeUpdate();
				
			}catch(Exception e){
				e.printStackTrace();
			}
		
	}
		
		if(count>0){
			System.out.println("Inserted Successfully");
		}else{
			System.out.println("Inserted Again");
		}
		
	}
	

}
