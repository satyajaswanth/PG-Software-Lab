To Run KD Tree:
javac KdTreeAlg.java
javac  RunKDTree.java

java RunKDTree.java 1  5 5 8 7(for Range Query)
 1 is for alpha value and  5 5 8 7 is a range query

To Run QuadTree:
javac  QuadTreeAlgorithm.java

java  QuadTreeAlgorithm 1
1 is for visualization
for rangequery we have to give range in query.txt


we will see the output in output.txt



 