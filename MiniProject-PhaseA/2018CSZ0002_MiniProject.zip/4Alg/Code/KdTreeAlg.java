import java.util.*;
import java.io.FileWriter;
public class KdTreeAlg{

/*
  Each node of kdtree will have a point and rectangle associated with it.
  so node will have points and Rectangle object;
*/

    // Tree variables
    int tree_size;    // KD Tree size
    Node root_node;   // KD Tree root

    //square of root node  
    /*double x_min = 700.0;
    double x_max = 100.0;
    double y_min = 500.0;
    double y_max = 100.0;*/
	double x_min = 0.0;
    double x_max = 10.0;
    double y_min = 0.0;
    double y_max = 10.0;
	int filename = 1;
	int option;

// Node class represents tree structure variables
private class Node {
	//node point
	Points point;
    //current node rectangle
	Rectangle rectangle;
	//leafs of kdtree 
    Node left_node,right_node;
	//constructor to initialize tree
	private Node(Points p,Rectangle rect) {
		point = p;
		rectangle = rect;
		left_node = null;
        right_node = null;
	}
}

//constructor to initialize empty kdtree
public KdTreeAlg(int op) {
	tree_size = 0;
	option = op;
}

//function to check is tree empty
public boolean isTreeEmpty() {
	return tree_size == 0;
}

//function to return tree size
public int getTreesize() {
	return tree_size;
}

//function to insert points to kdtree
public void insert(Points poi) {
	root_node = buildKDTree(root_node,poi,x_min,y_min,x_max,y_max,0);  
}
//function to check given point is inside the tree
public boolean PointInside(Points poi) {
	return (Inside(root_node,poi,0) != null);
}

//comparing points base on level
public int compare(Points pointa,Points pointb,int levels) {
	int result;
	if (levels % 2 == 0) {
		result = new Double(pointa.xData()).compareTo(new Double(pointb.xData()));
		if(result == 0) {
			return new Double(pointa.yData()).compareTo(new Double(pointb.yData()));
		} else {
			return result;
		}
	} else {
		result = new Double(pointa.yData()).compareTo(new Double(pointb.yData()));
		if(result == 0) {
			return new Double(pointa.xData()).compareTo(new Double(pointb.xData()));
		} else {
			return result;
		}
	}
}
//function to build kd tree
public Node buildKDTree(Node root,Points poi,double x_mins,double y_mins,double x_maxs,double y_maxs,int levels) {
	if(root == null) {
		tree_size++;
		return new Node(poi, new Rectangle(x_mins,y_mins,x_maxs,y_maxs));
	}
	int result = compare(poi,root.point,levels);
	//point add to left sub tree
	if(result < 0) {
		//vertical cut root rectangle
		if(levels % 2 == 0) {
			//building kdtree recursively
			root.left_node = buildKDTree(root.left_node,poi,x_mins,y_mins,root.point.xData(),y_maxs,levels + 1);
			RunKDTree.output.append("Left Points : "+poi.toString()+" Level "+levels+System.getProperty("line.separator"));
			save(poi,root.point);
		} else {   //horizontal rectangle cut
		    root.left_node = buildKDTree(root.left_node,poi,x_mins,y_mins,x_maxs,root.point.yData(),levels + 1);
			RunKDTree.output.append("Left Points : "+poi.toString()+" Level "+levels+System.getProperty("line.separator"));
			save(poi,root.point);
		}
	} else if (result > 0) {  //points add to right sub tree
		if (levels % 2 == 0) {   //root cut rectangle vertical side
            root.right_node = buildKDTree(root.right_node,poi,root.point.xData(),y_mins,x_maxs,y_maxs,levels + 1);
			RunKDTree.output.append("Right Points : "+poi.toString()+" Level "+levels+System.getProperty("line.separator"));
			save(poi,root.point);
		} else {   //horizontal cut the root rectangle
            root.right_node = buildKDTree(root.right_node,poi,x_mins,root.point.yData(),x_maxs,y_maxs,levels + 1);
			RunKDTree.output.append("Right Points : "+poi.toString()+" Level "+levels+System.getProperty("line.separator"));
			save(poi,root.point);
		}
	}
	return root;
}

public Points Inside(Node rootnode,Points poi,int levels) {
	if (rootnode != null) {
		int result = compare(poi,rootnode.point,levels);
		//check point at left size of tree
		if(result < 0) {
			return Inside(rootnode.left_node,poi, levels + 1);
		}
		//check point lies at right side
		else if (result > 0) {
			return Inside(rootnode.right_node,poi,levels + 1);
		} else {    //got the point 
            return rootnode.point;
		}
	}
	//point not found
	return null;
}

//check points inside given rectangle
public Iterable<Points> rangeQuery(Rectangle rects) {
	LinkedList<Points> queue = new LinkedList<Points>();
	pointrangeList(root_node,rects,queue,true);
    return queue;
}

//get all points lies inside given rectangle 
public void pointrangeList(Node rootnode, Rectangle rects, LinkedList<Points> queue, boolean xy_sort) {
	if (rootnode != null && rects.intersects(rootnode.rectangle)) {
		//check root lies inside rectangle
		if(rects.contains(rootnode.point)) {
			queue.add(rootnode.point);
		}
		if(xy_sort) {
			xy_sort = false;
			//System.out.print(rect.xmax()+" "+root.p.x()+" "+rect.xmin()+" "+root.p.x()+",");
            if(rects.getxmax() >= rootnode.point.xData() && rects.getxmin() <= rootnode.point.xData()){
				//recursive search at left subtree
				pointrangeList(rootnode.left_node, rects,queue,xy_sort);    
				//search at right sub tree 
                pointrangeList(rootnode.right_node,rects,queue,xy_sort);
			} else if(rects.getxmax() < rootnode.point.xData()){
				//search through right sub tree
				pointrangeList(rootnode.left_node,rects,queue,xy_sort);
			} else if(rects.getxmin() > rootnode.point.xData()){
				//search at left sub tree
                pointrangeList(rootnode.right_node,rects,queue,xy_sort); 
            }
		}else {
			xy_sort = true;
            if(rects.getymax() >= rootnode.point.yData() && rects.getymin() <= rootnode.point.yData()){
				//search at left sub tree
                pointrangeList(rootnode.left_node,rects,queue,xy_sort);     
                //search through right sub tree
				pointrangeList(rootnode.right_node,rects,queue,xy_sort);   
			} else if(rects.getymax() < rootnode.point.yData()){
				pointrangeList(rootnode.left_node,rects,queue,xy_sort);  
			} else if(rects.getymin() > rootnode.point.yData()){
				pointrangeList(rootnode.right_node,rects,queue,xy_sort);  
			}
		}
	}
}
public void save(Points poi,Points p1){
	try{
		if(option == 1){
			FileWriter fw = new FileWriter("files/"+filename+".txt");
			fw.write(poi.getID()+" "+poi.xData()+" "+poi.yData());
			fw.close();
			filename = filename + 1;
		}
		if(option == 2){
			FileWriter fw = new FileWriter("files/"+filename+".txt");
			fw.write(poi.getID()+" "+poi.xData()+" "+poi.yData()+System.getProperty("line.separator")+p1.getID()+" "+p1.xData()+" "+p1.yData());
			fw.close();
			filename = filename + 1;
		}
	}catch(Exception e){
		e.printStackTrace();
	}
}
}
