public class QuadPoints<TreeData extends Comparable<TreeData>> { 
	
	Point<TreeData> x_interval;   // x interval regions
    Point<TreeData> y_interval;   // y interval regions

public QuadPoints(Point<TreeData> x_interval, Point<TreeData> y_interval) {
	this.x_interval = x_interval;
    this.y_interval = y_interval;
}

//function to perform weather two regions overlap or not
public boolean TestIntersect(QuadPoints<TreeData> td) {
	if (x_interval.TestIntersect(td.x_interval))
		return true;
	if (y_interval.TestIntersect(td.y_interval))
		return true;
	return false;
}

// function to check regions contains given points or not
public boolean PointInside(TreeData x, TreeData y) {
	return x_interval.PointInside(x) && y_interval.PointInside(y);
}

// function to returns string type data of this object
public String toString() {
	return x_interval + " x " + y_interval;
}
}
