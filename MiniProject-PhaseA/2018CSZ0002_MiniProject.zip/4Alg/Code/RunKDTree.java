import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
public class RunKDTree {

	static ArrayList<Points> points;
	static KdTreeAlg tree;
	static int option;
	static StringBuilder output = new StringBuilder();
	//20 35 450 400
public static void main(String[] args) {
	int option = Integer.parseInt(args[0]);
	double x_min = 10;//658
    double y_min = 10;//260
	double x_max =  390;
    double y_max =  380;
	x_min = Double.parseDouble(args[1]);
	y_min = Double.parseDouble(args[2]);
	x_max = Double.parseDouble(args[3]);
	y_max = Double.parseDouble(args[4]);

	deleteFiles();
	
	tree = new KdTreeAlg(option);
	points = new ArrayList<Points>();
	ArrayList<String> list = new ArrayList<String>();
	try{
		BufferedReader br = new BufferedReader(new FileReader("points.txt"));
		String line = null;
		while((line = br.readLine())!=null){
			list.add(line);
		}
		br.close();
	}catch(Exception e){
		e.printStackTrace();
	}
    Points[] point = new Points[list.size()];
	for (int i = 0; i < list.size(); i++) {
		String arr[] = list.get(i).split("\\s+");
		int id = Integer.parseInt(arr[0]);
        double x = Double.parseDouble(arr[1]);
        double y = Double.parseDouble(arr[2]);
		point[i] = new Points(id,x, y);
        points.add(point[i]);
	}
	buildKDTree(points,true);
	System.out.println(output.toString());
	try{
		FileWriter fw = new FileWriter("output.txt");
		fw.write(output.toString());
		fw.close();
	}catch(Exception e){
		e.printStackTrace();
	}
	System.out.println("\nRange Query Result\n\n");
	Rectangle rectangle = new Rectangle(x_min, x_max, y_min, y_max);
	Iterable<Points> range = tree.rangeQuery(rectangle);
	java.util.Iterator<Points> itr = range.iterator();
	while(itr.hasNext()){
		Points p = itr.next();
		System.out.println(p.toString());
	}
}

public static void deleteFiles(){
	File path = new File("files");
	File[] dir = path.listFiles();
	for(int d=0;d<dir.length;d++){
		if(dir[d].isFile()){
			dir[d].delete();
		}
	}
}

public static void buildKDTree(ArrayList<Points> points, boolean xy_sort) {
	ArrayList<Points> sorted_points;
	if(points.size() > 2) {
		if(xy_sort) {
			sorted_points = sortByX(points);
            xy_sort = false;
		}else{
			sorted_points = sortByY(points);
			xy_sort = true;
		}
		int point_size = sorted_points.size();
        int median = point_size/2;
		tree.insert(sorted_points.get(median));
        ArrayList<Points> right = new ArrayList<Points>(sorted_points.subList(median+1,point_size));
        ArrayList<Points> left = new ArrayList<Points>(sorted_points.subList(0,median));
        buildKDTree(right,xy_sort);
        buildKDTree(left,xy_sort);
	}else{
		for(Points poi : points ) {
			tree.insert(poi);
		}
	}
}

public static ArrayList<Points> sortByX(ArrayList<Points> points){
	int num = points.size();
	int a,b;
	Points swaping;

	for(a=0;a<(num-1);a++){
		for(b=0;b<num-a-1;b++){
			if(points.get(b).xData() > points.get(b+1).xData()){
				swaping = points.get(b);
				points.set(b,points.get(b+1));
				points.set((b+1),swaping);
            }
		}
	}
	return points;
}

public static ArrayList<Points> sortByY(ArrayList<Points> points){
	int num = points.size();
	int a,b;
	Points swaping;
	for(a=0;a<(num-1);a++){
		for(b=0;b<num-a-1;b++){
			if(points.get(b).yData() > points.get(b+1).yData()) {
				swaping = points.get(b);
				points.set(b,points.get(b+1));
				points.set((b+1),swaping);
            }
		}
	}
	return points;
}
}
