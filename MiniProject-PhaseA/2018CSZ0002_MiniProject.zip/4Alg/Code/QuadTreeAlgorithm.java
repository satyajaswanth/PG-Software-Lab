import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class QuadTreeAlgorithm<TreeData extends Comparable<TreeData>, TreeValue>  {
	Node root_node;
	static StringBuilder output = new StringBuilder();
	static int option;
public void insert(TreeData xdata, TreeData ydata, TreeValue treevalue) {
	root_node = insertData(root_node, xdata, ydata, treevalue);
}

public Node insertData(Node parent, TreeData xdata, TreeData ydata, TreeValue treevalue) {
	if (parent == null) {
		//System.out.println("Root : "+xdata+" "+ydata+" "+treevalue);
		output.append("Root : "+xdata+" "+ydata+" "+treevalue+System.getProperty("line.separator"));
		return new Node(xdata, ydata, treevalue);
	}
	else if ( less(xdata, parent.x_coordinate) &&  less(ydata, parent.y_coordinate)) {
		parent.SW = insertData(parent.SW, xdata, ydata, treevalue);
		//System.out.println("Parent SW : "+parent.SW.data);
		output.append("Parent SW : "+parent.SW.data+System.getProperty("line.separator"));
	}
	else if ( less(xdata, parent.x_coordinate) && !less(ydata, parent.y_coordinate)) {
		parent.NW = insertData(parent.NW, xdata, ydata, treevalue);
		//System.out.println("Parent NW : "+parent.NW.data);
		output.append("Parent NW : "+parent.NW.data+System.getProperty("line.separator"));
	}
	else if (!less(xdata, parent.x_coordinate) &&  less(ydata, parent.y_coordinate)) {
		parent.SE = insertData(parent.SE, xdata, ydata, treevalue);
		//System.out.println("Parent SE : "+parent.SE.data);
		output.append("Parent SE : "+parent.SE.data+System.getProperty("line.separator"));
	}
	else if (!less(xdata, parent.x_coordinate) && !less(ydata, parent.y_coordinate)) {
		parent.NE = insertData(parent.NE, xdata, ydata, treevalue);
		output.append("Parent NE : "+parent.NE.data+System.getProperty("line.separator"));
		//System.out.println("Parent NE : "+parent.NE.data);
	}
	return parent;
}


//function to perform range query search   
public void rangeQuerySearch(QuadPoints<TreeData> rect) {
	rangeQuerySearch(root_node, rect);
}
//range query search
public void rangeQuerySearch(Node parent, QuadPoints<TreeData> rectangle) {
	if (parent == null) 
		return;
	TreeData x_min = rectangle.x_interval.min();
	TreeData y_min = rectangle.y_interval.min();
	TreeData x_max = rectangle.x_interval.max();
	TreeData y_max = rectangle.y_interval.max();
	if (rectangle.PointInside(parent.x_coordinate, parent.y_coordinate))
		System.out.println("    (" + parent.x_coordinate + ", " + parent.y_coordinate + ") " + parent.data);
	if ( less(x_min, parent.x_coordinate) &&  less(y_min, parent.y_coordinate)) 
		rangeQuerySearch(parent.SW, rectangle);
	if ( less(x_min, parent.x_coordinate) && !less(y_max, parent.y_coordinate)) 
		rangeQuerySearch(parent.NW, rectangle);
	if (!less(x_max, parent.x_coordinate) &&  less(y_min, parent.y_coordinate)) 
		rangeQuerySearch(parent.SE, rectangle);
        if (!less(x_max, parent.x_coordinate) && !less(y_max, parent.y_coordinate)) 
			rangeQuerySearch(parent.NE, rectangle);
}

//Function to compare one Tree node with other tree node 
public boolean less(TreeData t1, TreeData t2) { 
	return t1.compareTo(t2) <  0; 
}

public boolean eq(TreeData t1, TreeData t2) { 
	return t1.compareTo(t2) == 0;
}

//data structures for quad tree
private class Node {
	//x & y coordinates
	TreeData x_coordinate, y_coordinate;
	//subtrees 
    Node NW, NE, SE, SW;
	// data value
    TreeValue data;  
	
//data structures initialization for quad tree
Node(TreeData x_coordinate, TreeData y_coordinate, TreeValue data) {
	this.x_coordinate = x_coordinate;
	this.y_coordinate = y_coordinate;
    this.data = data;
}
}
public static void main(String args[])throws Exception{
	int option = Integer.parseInt(args[0]);
	QuadTreeAlgorithm<Integer, String> st = new QuadTreeAlgorithm<Integer, String>();
	BufferedReader br = new BufferedReader(new FileReader("points.txt"));
	String line = null;
	while((line = br.readLine())!=null){
		String arr[] = line.split("\\s+");
		String id = arr[0].trim();
		Integer x = (int)Double.parseDouble(arr[1].trim()); 
		Integer y = (int)Double.parseDouble(arr[2].trim()); 
		st.insert(x, y, id);
	}
	br.close();
	System.out.println(output.toString());
	FileWriter fw = new FileWriter("output.txt");
	fw.write(output.toString());
	fw.close();

	
	System.out.println("\n\nRange Query\n\n");
	br = new BufferedReader(new FileReader("query.txt"));
	while((line = br.readLine())!=null){
		String arr[] = line.split("\\s+");
		Integer xmin = Integer.parseInt(arr[0].trim());
		Integer ymin = Integer.parseInt(arr[1].trim());
		Integer xmax = Integer.parseInt(arr[2].trim()); 
		Integer ymax = Integer.parseInt(arr[3].trim());
		Point<Integer> x = new Point<Integer>(xmin, xmax);
        Point<Integer> y = new Point<Integer>(ymin, ymax);
        QuadPoints<Integer> rect = new QuadPoints<Integer>(x, y);
		System.out.println(rect + " : ");
        st.rangeQuerySearch(rect);
	}
	br.close();
}
public void save(Points poi,Points p1){
 int filename = 1;
        int option=1;

        try{
                if(option == 1){
                        FileWriter fw = new FileWriter("quad files/"+filename+".txt");
                        fw.write(poi.getID()+" "+poi.xData()+" "+poi.yData());
                        fw.close();
                        filename = filename + 1;
                }
                if(option == 2){
                        FileWriter fw = new FileWriter("quad files/"+filename+".txt");
                        fw.write(poi.getID()+" "+poi.xData()+" "+poi.yData()+System.getProperty("line.separator")+p1.getID()+" "+p1.xData()+" "+p1.yData());
                        fw.close();
                        filename = filename + 1;
                }
        }catch(Exception e){
                e.printStackTrace();
        }
}
                  
}
