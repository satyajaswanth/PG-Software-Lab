import java.util.Arrays;
import java.util.Comparator;
public class Points implements Comparable<Points> {

    // x coordinates
    double xdata;    
	 // y coordinates
    double ydata; 
	//point id
	int id;
public Points(int i,double xpoint, double ypoint) {
	if(Double.isInfinite(xpoint) || Double.isInfinite(ypoint))
		throw new IllegalArgumentException("Coordinate should be finite");
    if(Double.isNaN(ypoint) || Double.isNaN(ypoint))
		throw new IllegalArgumentException("Coordinate should not be NaN");
	xdata = xpoint;
    ydata = ypoint;
	id = i;
}
public int getID(){
	return id;
}
public double xData(){
	return xdata;
}

public double yData(){
	return ydata;
}

public String toString() {
	return "(" +id+", "+ xdata + ", " + ydata + ")";
}

public int compareTo(Points pointa) {
	if(this.ydata < pointa.ydata)
		return -1;
    if(this.ydata > pointa.ydata)
		return +1;
    if(this.xdata < pointa.xdata)
		return -1;
    if(this.xdata > pointa.xdata)
		return +1;
	return 0;
}
    
}



