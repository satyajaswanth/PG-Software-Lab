public class Point<TreeData extends Comparable<TreeData>> {
	// tree min point
	TreeData minpoint; 
	// tree max point
    TreeData maxpoint;    

public Point(TreeData minpoint, TreeData maxpoint) {
	if (Inside(maxpoint, minpoint)) 
		throw new RuntimeException("Illegal argument");
	this.minpoint = minpoint;
    this.maxpoint = maxpoint;
}

// function to return min point
public TreeData min() {
	return minpoint;
}

// function to return max point
public TreeData max() {
	return maxpoint;
}

// function to check given x point overlap between min and max point
public boolean PointInside(TreeData x) {
	return !Inside(x, minpoint) && !Inside(maxpoint, x);
}

//function to check weather two regions intersects or not 
public boolean TestIntersect(Point<TreeData> pointb) {
	Point<TreeData> pointa  = this;
	if (Inside(pointa.maxpoint, pointb.minpoint))
		return false;
    if (Inside(pointb.maxpoint, pointa.minpoint))
		return false;
	return true;
}

//function to check weather two intervals are equal or not
public boolean equals(Point<TreeData> pointb) {
	Point<TreeData> pointa  = this;
	return pointa.minpoint.equals(pointb.minpoint) && pointa.maxpoint.equals(pointb.maxpoint);
}

// comparison helper functions
//function to check two points are equal or not
public boolean Inside(TreeData xpoint, TreeData ypoint) {
	return xpoint.compareTo(ypoint) < 0;
}

// function to returns string type data of this object
public String toString() {
	return "[" + minpoint + ", " + maxpoint + "]";
}

}