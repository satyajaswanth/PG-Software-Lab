
public class Rectangle {
	//min & max x and y coordinates
    double x_min, y_min;
    double x_max, y_max;

// constructor to build rectangle using given min and max coordinates
public Rectangle(double x_min, double y_min, double x_max, double y_max) {
	double temp = 0;
	if(x_min > x_max){
		temp = x_max;
		x_max = x_min;
		x_min = temp;
	}
	if(y_min > y_max) {
		temp = y_max;
        y_max = y_min;
        y_min = temp;
	}
	this.x_min = x_min;
    this.y_min = y_min;
    this.x_max = x_max;
    this.y_max = y_max;
}

// functions to get min and max coordinates values
public double getxmin() { 
	return x_min;
}
public double getymin() { 
	return y_min;
}
public double getxmax() {
	return x_max;
}
public double getymax() { 
	return y_max;
}

// function to get height and width rectangle
public double getwidth() { 
	return x_max - x_min;
}
public double getheight() { 
	return y_max - y_min; 
}

// check intersection
public boolean intersects(Rectangle rect) {
	return this.x_max >= rect.x_min && this.y_max >= rect.y_min && rect.x_max >= this.x_min && rect.y_max >= this.y_min;
}

public double getdistanceTo(Points point) {
	return Math.sqrt(this.getdistanceSquaredTo(point));
}

public double getdistanceSquaredTo(Points point) {
	double x = 0.0;
	double y = 0.0;
	if(point.xData() < x_min)
		x = point.xData() - x_min;
	else if (point.xData() > x_max)
		x = point.xData() - x_max;
	if(point.yData() < y_min) 
		y = point.yData() - y_min;
	else if (point.yData() > y_max)
		y = point.yData() - y_max;
	return x*x + y*y;
}

// function to check rectangle contains given point
public boolean contains(Points point) {
	return (point.xData() >= x_min) && (point.xData() <= x_max) && (point.yData() >= y_min) && (point.yData() <= y_max);
}

public boolean equals(Object obj) {
	if(obj == this) 
		return true;
    if(obj == null)
		return false;
	if(obj.getClass() != this.getClass())
		return false;
	Rectangle current = (Rectangle) obj;
	if(this.x_min != current.x_min)
		return false;
	if(this.y_min != current.y_min)
		return false;
	if(this.x_max != current.x_max)
		return false;
	if(this.y_max != current.y_max)
		return false;
	return true;
}
// return string object of rectangle
public String toString() {
	return "[" + x_min + ", " + x_max + "] x [" + y_min + ", " + y_max + "]";
}
}


