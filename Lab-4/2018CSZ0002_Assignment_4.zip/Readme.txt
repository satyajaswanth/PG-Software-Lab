Execution process:
for Question1:
gcc main_all.c addition.c multiplication.c subtraction.c division.c

for Question 2 Make:
1.for default  action :  //for default option
make

2.for addition subtraction  action:  // for Option B
make main_add_sub

3.for multiplication division action:  // for Option C
make main_mul_div

for cleaning make file :
make clean

for Combining and linking source files:
gcc main.c header.h   //for default option

gcc -D ADD_SUB main.c header.h   // for Option B

gcc -D MUL_DIV main.c header.h  // for Option C