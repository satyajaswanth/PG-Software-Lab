#include<stdio.h>
#include "header.h"

int main(){
        int numb3;
        int numb4;
        int result;
        int choice = 0;
#ifndef ADD_SUB
#ifndef MUL_DIV
        printf("\nCalculator menu\n");
        printf("1.Addition\n");
        printf("2.Subtraction\n");
        printf("3.Multiplication\n");
        printf("4.Division\n");

        printf("\nEnter your choice:");
        scanf("%d",&choice);

        if(choice < 1 || choice > 4) {
                printf("\nInalid choice\n");
                return 1;
        }
        printf("\nEnter first number:");
        scanf("%d",&numb3);
        printf("\nEnter second number:");
        scanf("%d",&numb4);
	switch(choice) {
                case 1: result = addition(numb3,numb4);
                        printf("\nAddition of %d and %d is %d\n",numb3,numb4,result);
                        break;
                case 2: result = subtraction(numb3,numb4);
                        printf("\nSubtraction of %d and %d is %d\n",numb3,numb4,result);
                        break;
                case 3: result = multiplication(numb3,numb4);
                        printf("\nMultiplication of %d and %d is %d\n",numb3,numb4,result);
                        break;
                case 4: result = division(numb3,numb4);
                        printf("\nDivision of %d and %d is %d\n",numb3,numb4,result);
                        break;
        }
#endif
#endif
#ifdef ADD_SUB
        printf("\nCalculator menu\n");
        printf("1.Addition\n");
        printf("2.Subtraction\n");
        printf("\nEnter your choice:");
        scanf("%d",&choice);

        if(choice < 1 || choice > 2) {
                printf("\nInalid choice\n");
                return 1;
        }
        printf("\nEnter first number:");
        scanf("%d",&numb3);
        printf("\nEnter second number:");
        scanf("%d",&numb4);
        switch(choice) {
                case 1: result = addition(numb3,numb4);
                        printf("\nAddition of %d and %d is %d\n",numb3,numb4,result);
                        break;
                case 2: result = subtraction(numb3,numb4);
                        printf("\nSubtraction of %d and %d is %d\n",numb3,numb4,result);
                        break;

	}
#endif
#ifdef MUL_DIV
        printf("\nCalculator menu\n");
        printf("1.Multiplication\n");
        printf("2.Division\n");

        printf("\nEnter your choice:");
        scanf("%d",&choice);

        if(choice < 1 || choice > 2) {
                printf("\nInalid choice\n");
                return 1;
        }
        printf("\nEnter first number:");
        scanf("%d",&numb3);
        printf("\nEnter second number:");
        scanf("%d",&numb4);
        switch(choice) {
                case 1: result = multiplication(numb3,numb4);
                        printf("\nMultiplication of %d and %d is %d\n",numb3,numb4,result);
                        break;
                case 2: result = division(numb3,numb4);
                        printf("\nDivision of %d and %d is %d\n",numb3,numb4,result);
                        break;
        }
#endif
        return 0;
}


int addition(int numb1, int numb2) {
   if (!numb1)
      return numb2;
   else
      return addition((numb1 & numb2) << 1, numb1 ^ numb2);
}

int subtraction(int numb1, int numb2)
{
    if (numb2 == 0)
        return numb1;
    return subtraction(numb1 ^ numb2, (~numb1 & numb2) << 1);
}

int multiplication(int numb1, int numb2)
{
   int temp;
   temp = numb1;
   while( numb2 > 1)
{
     numb1 = do_add(numb1, temp);
     numb2 = numb2 - 1;
}
   return numb1*numb2;
}

int do_add(int a, int b)
{
   a = a + b;
   return a;
}

int division(numb1,numb2)
{
int sign=1;
int quotient =1;
int temp;
if(numb1 < 0)
      {
            numb1 = -numb1;
            sign = -1;
      }
      else if(numb2 < 0)
      {
            numb2 = -numb2;
            sign = sign * (-1);
      }
      temp = numb2;
      if((numb1 != 0 && numb2 != 0) && (numb2 < numb1))
      {
            while(((temp<<1) - numb1) < 0)
            {
                  temp = temp<<1;
                  quotient = quotient<<1;
            }
            while((temp + numb2) <= numb1)
            {
                  temp = temp + numb2;
                  quotient = quotient + 1;
            }
      }
      else if(numb1 == 0)
      {
            quotient = 0;
      }
      if(numb2)
      {
            return quotient * sign;
      }
      else
      {
            printf("\nDividing A Number By Zero Not Possible\n");
      }
      return 0;
}

