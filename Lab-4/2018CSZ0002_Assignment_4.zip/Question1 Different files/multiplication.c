/* author: B S Jaswanth 2018CSZ0002*/

int multiplication(int numb1, int numb2)
{
   int temp;
   temp = numb1;
   while( numb2 > 1)
{
     numb1 = do_add(numb1, temp);
     numb2 = numb2 - 1;
}
   return numb1*numb2;
}
 
int do_add(int a, int b)
{
   a = a + b;
   return a;
}
 

