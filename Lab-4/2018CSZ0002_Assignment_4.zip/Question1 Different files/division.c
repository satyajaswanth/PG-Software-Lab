/* author: B S Jaswanth 2018CSZ0002*/

#include<stdio.h>


int division(numb1,numb2)
{
int sign=1;
int quotient =1;
int temp;
if(numb1 < 0)
      {
            numb1 = -numb1;
            sign = -1;
      }
      else if(numb2 < 0)
      {
            numb2 = -numb2;
            sign = sign * (-1);
      }
      temp = numb2; 
      if((numb1 != 0 && numb2 != 0) && (numb2 < numb1))
      {
            while(((temp<<1) - numb1) < 0)
            {
                  temp = temp<<1;
                  quotient = quotient<<1;
            }
            while((temp + numb2) <= numb1)
            {
                  temp = temp + numb2;
                  quotient = quotient + 1;
            }
      }
      else if(numb1 == 0)
      {
            quotient = 0;
      }
      if(numb2)
      {
            return quotient * sign;
      }
      else
      {
            printf("\nDividing A Number By Zero Not Possible\n");
	  
      }
      return 0;
}
