/* author: B S JASWANTH 2018CSZ0002*/

int subtraction(int numb1, int numb2)
{
    if (numb2 == 0)
        return numb1;
    return subtraction(numb1 ^ numb2, (~numb1 & numb2) << 1);
}
