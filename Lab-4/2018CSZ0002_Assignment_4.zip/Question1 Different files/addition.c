/* author: B S Jaswanth 2018CSZ0002*/


int addition(int numb1, int numb2) {
   if (!numb1)
      return numb2;
   else
      return addition((numb1 & numb2) << 1, numb1 ^ numb2);
}
