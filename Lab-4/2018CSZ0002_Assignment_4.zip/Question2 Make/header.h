/* author: B S Jaswanth 2018CSZ0002*/

//Function declaration of addition
int addition(int numb1, int numb2);

//Function declaration of subtraction
int subtraction(int numb1, int numb2);

//Function declaration of multiplication
int multiplication(int numb1, int numb2);

//Function declaration of division
int division(int numb1, int numb2);
