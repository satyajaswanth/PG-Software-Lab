/* author: B S Jaswanth 2018CSZ0002*/

#include<stdio.h>
#include "header.h"

int main(){
        int numb3;
        int numb4;
        int result;
        int choice = 0;
        printf("\nCalculator menu\n");
        printf("1.Addition\n");
        printf("2.Subtraction\n");
        printf("\nEnter your choice:");
        scanf("%d",&choice);
        if(choice < 1 || choice > 2) {
                printf("\nInalid choice\n");
                return 0;
        } 
        printf("\nEnter first number:");
        scanf("%d",&numb3);
        printf("\nEnter second number:");
        scanf("%d",&numb4);
        switch(choice) {
                case 1: result = addition(numb3,numb4);
                        printf("\nAddition of %d and %d is %d\n",numb3,numb4,result);
                        break;
                case 2: result = subtraction(numb3,numb4);
                        printf("\nSubtraction of %d and %d is %d\n",numb3,numb4,result);
                        break;
	}
	return 0;
}
