/* author: B S Jaswanth 2018CSZ0002*/

#include<stdio.h>

int main(){
        int numb3;
        int numb4;
        int result;
        int choice = 0;
        printf("\nCalculator menu\n");
        printf("1.Multiplication\n");
        printf("2.Division\n");
        printf("\nEnter your choice:");
        scanf("%d",&choice);
        if(choice < 1 || choice > 2) {
                printf("\nInalid choice\n");
                return 1;
        }
        printf("\nEnter first number:");
        scanf("%d",&numb3);
        printf("\nEnter second number:");
        scanf("%d",&numb4);
	switch(choice) {
		case 1: result = multiplication(numb3,numb4);
                        printf("\nMultiplication of %d and %d is %d\n",numb3,numb4,result);
                        break;
                case 2: result = division(numb3,numb4);
                        printf("\nDivision of %d and %d is %d\n",numb3,numb4,result);
                        break;
        }
        return 0;
}


