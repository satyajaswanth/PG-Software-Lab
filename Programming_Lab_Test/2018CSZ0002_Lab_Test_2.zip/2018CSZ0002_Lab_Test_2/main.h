
#ifndef MAIN_H
#define MAIN_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>


struct node 
{
	int employee_num;
	int age;
	int salary;
	struct node *lchild;
	struct node *rchild;
};

FILE *fp;

typedef struct node node;
extern node *root;

extern void Print_Inorder(node *);
extern node *Delete_from_BStree(node *,int);
extern void Insert_into_BStree();

#endif
