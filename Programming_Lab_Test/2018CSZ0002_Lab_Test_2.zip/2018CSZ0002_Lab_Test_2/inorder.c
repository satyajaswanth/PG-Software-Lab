
#include "main.h"
void Print_Inorder(node *root)
{
	if(root==NULL)
		return;
	Print_Inorder(root->lchild);
	printf("%d\t%d\t%d\n ",root->employee_num, root->age, root->salary);
	Print_Inorder(root->rchild);

}
