#include "main.h"

node *root = NULL;

int main(void)
{
	int ch,data;
	char str[10];
	fp = fopen("input.txt","r");		
	root=NULL;

x:	while(1)
	{	
	
	printf("\n\n=======================================================");
	printf("\n1:Insertion\t2:Deletion\t3:Inorder\n4:Exit\n");
	printf("=======================================================\n\n");

	printf("\nEnter the choice:");
	if(fgets(str,10,stdin) == NULL)
		printf("Fgets failed\n");
	
	ch=atoi(str);

	switch(ch)
	{
	
		case 1:	  
			   Insert_into_BStree();
			   break;

		case 2:	   printf("Enter data:  ");
			   fgets(str,10,stdin);
			   data=atoi(str);
			   root=Delete_from_BStree(root,data);
			   break;

		case 3:    Print_Inorder(root);
			   break;

		case 4:    exit(0);

		default:
			   printf("**************************************************************\n");
			   printf("Enter valid choice\n");
			   printf("**************************************************************\n");
			   exit(0);
			
	}/*end of switch*/
	}/*end of while*/

	return 0;
}/*end of main*/







