#include "main.h"

node *insertion_rec(node *,int, int, int);

void Analyzerecord(char *stream)
{

        int employee_num;
        int salary;
        int age;

        employee_num = atoi(strtok( stream, ","));
        age = atoi(strtok( NULL, ","));
        salary = atoi(strtok( NULL, ","));
        root = insertion_rec( root, employee_num, age, salary );
        
}

void Insert_into_BStree()
{
	char *stream;
        stream = (char *)malloc(sizeof(char) * 50);
        if(fgets(stream, 50, fp) != NULL)
                Analyzerecord(stream);
	else
		printf("\n No more records in input text file\n");
        

}
node* insertion_rec(node* root,int employee_num, int age, int salary)
{
    if(root==NULL)
    {
        node* new=malloc(sizeof(node));
        new->employee_num= employee_num;
	new->age = age;
	new->salary = salary;
        new->lchild=new->rchild=NULL;
        return new;        
    }
    else if( employee_num < root->employee_num)
        root->lchild=insertion_rec(root->lchild, employee_num, age, salary);
    else if( employee_num > root->employee_num)
        root->rchild=insertion_rec(root->rchild, employee_num, age, salary);
    else
        printf("duplicate key\n");

    return root;
}

