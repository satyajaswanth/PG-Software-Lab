#include "main.h"

node *Delete_from_BStree(node *root,int data)
{	
	node *current=root;
	node *parent=NULL;
	node *suc=NULL;
	node *temp=NULL;
	
	if(root == NULL )
	{
		printf("No Node to delete\n");
		return root;
	}

	while(current != NULL )
	{
		if( data == current->employee_num )
			break;
		
		parent=current;
		current= (data < current->employee_num) ? (current->lchild) :(current->rchild) ;
		
	}
	
	if(current == NULL )
	{
		printf("Data to be deleted not found\n");
		return root;
	}

	
	if(current->lchild == NULL)
		temp=current->rchild;
	else if(current->rchild == NULL)
		temp=current->lchild;

	else
	{
		suc=current->rchild;
	
		while(suc->lchild != NULL )	
			suc=suc->lchild;

		suc->lchild=current->lchild;
		temp=current->rchild;
	}		
	
	if(parent == NULL)
		return temp;

	if(parent->lchild == current )
		parent->lchild=temp;
	else
		parent->rchild=temp;
	
	free(current) ;
	return root;

}

