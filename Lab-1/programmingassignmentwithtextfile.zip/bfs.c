#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define NLENGTH 10
#define ELENGTH 25
/*
  * To store nodes along with their edges
  */
struct Edges_List {
	int s_node;	//starting node
	int e_node;	//ending node
	int edge;
	struct Edges_List *next;
} *present_edge = NULL;
/*
  * List of all nodes
 */
struct Nodes_List {
	int node;
	struct Nodes_List *prev;
	struct Nodes_List *next;
	struct Edges_List *path;
} *head = NULL, *present_node = NULL;


//fuction declaration
struct Nodes_List *create_node(void);
struct Edges_List *create_edge(void);
int tokenize(char *,struct Edges_List*);
struct Nodes_List * search_node( int);
int free_nodes_with_no_edges(struct Nodes_List *);
void do_bfs(struct Nodes_List *);
struct Nodes_List * find(int );

int total_nodes = 0;
int start_node=0;
int end_node=0;
int edge_value =0;
int main(void)
{
	FILE *nodes_fp;
	FILE *edges_fp;
	char nodes_str[NLENGTH];  //to store input from file temperorly
	char edges_str[ELENGTH];
	struct Nodes_List *exact_node  = NULL;

	if(!(nodes_fp = fopen("Nodes.txt", "r"))) {
		printf("\nUnable to open Nodes.txt file\n");
		exit(0);
	}

	//inserting nodes to Nodes_List
	while(fgets(nodes_str,  NLENGTH, nodes_fp)) {
		struct Nodes_List* nodes = NULL;
		nodes=create_node();
		if(!nodes) {
			printf("\nUnable to create vertices node\n");
			exit(0);
		}
		total_nodes = total_nodes + 1;
		nodes->node = atoi(nodes_str);
		if(head == NULL) {
			head = nodes;
			present_node = head;
        		} else {
			nodes->prev=present_node;
            			present_node->next  = nodes;
			present_node = present_node->next;
		}
	}
	fclose(nodes_fp);


	if(!(edges_fp = fopen("Edges.txt", "r"))) {
		printf("\nUnable to open Edges.txt file\n");
		exit(0);
	}

	//inserting edges from file to Edges_List
	while(fgets(edges_str, ELENGTH, edges_fp)) {
        	struct Edges_List* edges = NULL;
        	edges=create_edge();
		if(!edges) {
			printf("\nUnable to create edge \n");
			exit(0);
		}

		if(tokenize(edges_str,edges)) {
			printf("\n Unable to get values from input\n");
			exit(0);
		}

		//searching the exact node
		if(!(exact_node = search_node(edges->s_node))) {
			printf("\nNode doesn't exit");
			exit(0);
		}
		if(exact_node->path == NULL) {
			exact_node->path = edges;
			present_edge = edges;
		} else {
			present_edge->next = edges;
            			present_edge = present_edge->next;
		}
	}
	free_nodes_with_no_edges(head);
	do_bfs(head);
	return 0;
}

struct Nodes_List *create_node(void)
{
	struct Nodes_List *node = (struct Nodes_List  *)malloc(sizeof(struct Nodes_List));
	if(node == NULL) {
		return NULL;
	}
	node->prev = NULL;
	node->next = NULL;
	node->path= NULL;
	return node;
}

struct Edges_List *create_edge(void)
{
	struct Edges_List *edge = (struct Edges_List *)malloc(sizeof(struct Edges_List));
	if(edge == NULL) {
		return edge;
	}
	edge->next = NULL;
	return edge;
}

int tokenize(char *str,struct Edges_List* edges)
{
	int i;
	char string[3];
	char *token;

	token = strtok(str," ");
	edges->s_node=atoi(token);
	for(i = 1; token; i++) {
		token = strtok(NULL," ");
		if(i==1){
			edges->e_node=atoi(token);
		}
		if(i==2){
            			edges->edge=atoi(token);
		}
        	}
	return 0;
}

struct Nodes_List * search_node(int node_value)
{
	struct Nodes_List *temp = head;
	while(temp != NULL)  {
		if(temp->node== node_value) {
			return temp;
		}
		temp = temp->next;
	}
	return NULL;
}
int free_nodes_with_no_edges(struct Nodes_List * node)
{
	struct Nodes_List *free_node = NULL;
	if(node == NULL) {
		return 1;
	}
	while((node->path == NULL) && (node->next != NULL)) {
		node = node->next;
		node->prev = NULL;
		free(head);
		head = node;
	}
	while(node->path !=NULL) {
		if(node->next != NULL) {
			if(node->next->path != NULL) {
				node = node->next;
			} else {
				free_node = node->next;
				node->next = node->next->next;
				free(free_node);
				node->next->prev = node;
			}
		} else {
			return 0;
		}
	}
	free(node);
	return 0;
}

void do_bfs(struct Nodes_List *start)
{
	int Queue_nodes[total_nodes];
	int Queue_edges[total_nodes];
	int front = 0;
	int rear = -1;
	int nodes_array[total_nodes];
    	int count =0;
	int i;
	long int sum = 0;
	struct Nodes_List * temp_node = NULL;

	nodes_array[0] = start->node;
	while( head->next) {
		while(start->path != NULL) {
			Queue_nodes[front] = start->path->e_node;
			Queue_edges[front] = start->path->edge;
			start->path = start->path->next;
			front = front + 1;
		}
		if(start == head) {
			temp_node = head;
			if(head->next) {
				head = head->next;
				head->prev = NULL;
				free(temp_node);
			} else {
				goto out;
			}
		} else {
			temp_node = start;
			if(start->next) {
				start->prev->next = start->next;
				start->next->prev = start->prev;
				free(start);
			}
		}
		temp_node = find(Queue_nodes[rear + 1]);
		printf(" temp %p",temp_node);
		if(temp_node != NULL) {
			start =temp_node;
		} else {
			start = head;
		}
		for(i = 0; i <= count; i++) {
			if(nodes_array[i] == Queue_nodes[rear + 1]) {
				goto pop;
			}
		}
		count = count +1;
		nodes_array[count] = Queue_nodes[rear + 1];
		sum = sum + Queue_edges[rear + 1];
	pop:	rear = rear + 1;
	}
     out: 	 while(rear < front) {
		for(i=0;i<=count;i++){
			if(nodes_array[i] == Queue_nodes[rear+1]){
				break;
			}
		}
		if(i==count){
			count = count+1;
			nodes_array[count]= Queue_nodes[rear+1];
			sum=sum+Queue_edges[rear+1];
			rear=rear+1;
		}
		rear=rear+1;
	}
	//Printing nodes
	printf("\nNodes visited:\n");
	for(i = 0; i <=count; i++) {
		printf("%d---",nodes_array[i]);
		printf(" count %d", count);
	}
}

struct Nodes_List * find(int s_node)
{
	struct Nodes_List * temp = head;
	while(temp != NULL) {
		if(temp->node == s_node) {
			return temp;
		}
		temp = temp->next;
	}
	return NULL;
}