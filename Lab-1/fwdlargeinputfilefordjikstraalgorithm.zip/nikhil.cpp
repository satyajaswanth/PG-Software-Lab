/**
Name : J Nikhil kumar 
Entry number : 2018CSM1011
Lab : PG Software lab 
Attached readme document for compilation and execution procedure.
**/ 

/**   HEADER FILES  **/
 
#include<bits/stdc++.h>

#define pairs  pair<long long int, long long  int> 
#define INF 1000000000
#define ii pair<long long int, long long int> 
#define vi vector<long long int> 
#define vii vector<ii> 

using namespace std;
 

/* Execution of program starts from here  */  

int main()
{
     ifstream fin;
     ofstream fout;
     long long int node[5000001],i=0;
     fout.open("nodes.txt", ios::out);
     long long int total_nodes=50000 ;
     long long int total_nodes1=49990 ;
     while(total_nodes1!=9){
      fout << total_nodes1 << endl ;
      node[i++]=total_nodes1;
      total_nodes1--;
     }  
     fout.close() ;
     fout.open("edges.txt", ios::in);
      long long int total_edges=2*500000 ; 
     pairs p[total_edges]; 
    for (int i =0; i<total_edges; i++){
        p[i].first=((rand()%50000)+10); 
        p[i].second =((rand()%50000)+10); 
        while(p[i].first== p[i].second)
        {
          p[i].first=((rand()%50000)+10); 
          p[i].second =((rand()%50000)+10);
        }
    }
    set<pairs> s;   
    set<pairs> :: iterator it; 

    for (int i =0; i<total_edges; i++){
        s.insert(p[i]); 
    }
    for (it = s.begin(); it!=s.end(); it++){
        pairs m = *it ;
      fout<<m.first<<" "<<m.second<<" " << ((rand()%50000)+50000) << endl;
     }  
       fout.close();
 
    return 0; 
    
   }
