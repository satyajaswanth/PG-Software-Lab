Steps to execute:

First give your path in fname
where all the three files are present like

fname = C:\Users\Desktop.

to check whether the files are present or not after assigning the path we can do compile

javac Shortest.java

execution 
java Shortest
Enter Nodes File Name:
Nodes.txt
Enter Edges File Name:
Edges.txt
Enter Source to go:
6
Enter Destination for getting path:
9

Output:
6 to 9
Number of Nodes:11
Shortest Path:[No path found]
