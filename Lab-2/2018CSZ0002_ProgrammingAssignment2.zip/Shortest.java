import java.io.*;
import java.util.*;

public class Shortest<T extends Comparable<T>> {

	public enum State { nv };

	private ArrayList<Vertex> ver;
	private ArrayList<Edge> ed;

	public Shortest()
	{
		ver = new ArrayList<Vertex>();
		ed = new ArrayList<Edge>();
	}
	
	public void add(T s, T d, int w)
	{
		Edge temp = fe(s, d);
		if (temp != null)
		{			
			System.out.println("Edge " + s + "," + d + " already exists.");
			temp.w = w;
		}
		else
		{			
			Edge e = new Edge(s, d, w);
			ed.add(e);
		}
	}
	
	private Edge fe(Vertex v1, Vertex v2)
	{
		for (Edge each : ed)
		{
			if (each.s.equals(v1) && each.d.equals(v2))
			{
				return each;
			}
		}
		return null;
	}
	
	private Edge fe(T s, T d)
	{
		for (Edge each : ed)
		{
			if (each.s.val.equals(s) && each.d.val.equals(d))
			{
				return each;
			}
		}
		return null;
	}
	
	private Vertex fv(T v)
	{
		for (Vertex each : ver)
		{			
			if (each.val.compareTo(v)==0)
				return each;
		}
		return null;
	}
	
	private void re()
	{
		for (Vertex each : ver)
		{
			each.md = Integer.MAX_VALUE;
			each.pre = null;
		}
	}
	
	private boolean dij(T v1)
	{
		if (ver.isEmpty()) return false;
		
		re();
		
		Vertex source = fv(v1);
		if (source==null) return false;
		
		source.md = 0;
		
		LinkedList<Vertex> pq = new LinkedList<>();
		pq.add(source);

		while (!pq.isEmpty())
		{
			Vertex u = pq.poll();
			
			for (Vertex v : u.o)
			{				
				Edge e = fe(u, v);
				if (e==null) return false;
				
				int td = u.md + e.w;
				if (td < v.md)
				{
					
					pq.remove(v);
					v.md = td;
					
					v.pre = u;
					pq.add(v);
				}
			}
		}
		
		return true;
	}
	
	class Edge
	{
		Vertex s;
		Vertex d;
		int w;
		
		public Edge(T v1, T v2, int w)
		{
			s = fv(v1);
			if (s == null)
			{
				s = new Vertex(v1);
				ver.add(s);
			}
			d = fv(v2);
			if (d == null)
			{
				d = new Vertex(v2);
				ver.add(d);
			}
			this.w = w;

			s.addo(d);
			
		}
	}
	
	class Vertex implements Comparable<Vertex>
	{
		T val;
		
		Vertex pre = null;
		int md = Integer.MAX_VALUE;
		
		List<Vertex> o;
		State state;

		
		public Vertex(T val)
		{
			this.val = val;			
			o = new ArrayList<>();
			state = State.nv;
		}
		
		public int compareTo(Vertex other)
		{
			return Integer.compare(md, other.md);
		}

		
		public void addo(Vertex vert)
		{
			o.add(vert);
		}

		
	}
	private List<String> path(Vertex tar)
	{
		List<String> path = new ArrayList<String>();
		
		if (tar.md==Integer.MAX_VALUE)
		{
			path.add("No path found");
			return path;
		}
		
		for (Vertex v = tar; v !=null; v = v.pre)
		{			
			if(v==tar){
				path.add(v.val+"   Length:"+v.md);
			}else{
				path.add(v.val.toString());
			}
		}
		
		Collections.reverse(path);
		
		return path;
	}
	
	public List<String> gp(T s, T d)
	{
		boolean test = dij(s);
		if (test==false) return null;
		List<String> path = path(fv(d));
		return path;
	}
	
	public static void main(String[] args) {
		
		String fname = "C:/Users/HEMA/Desktop/";
		
		Scanner sn = new Scanner(System.in);
		System.out.println("Enter Nodes File Name:");
		String node = sn.next();
		System.out.println("Enter Edges File Name:");
		String edge = sn.next();		
		System.out.println("Enter Source to go:");		
		String src = sn.next();
		System.out.println("Enter Destination for getting path:");	
		String des = sn.next();
		
		LinkedHashSet lhs1 = new LinkedHashSet();
		
		File f1 = new File(fname+node);
		if(f1.exists()){
			
			try{
				
				BufferedReader br = new BufferedReader(new FileReader(fname+node));
				String s = "";
				while((s = br.readLine())!=null){
					for(int i=0;i<s.split(" ").length;i++){
						lhs1.add(s.split(" ")[i]);
					}
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}else{
			
			System.out.println("Nodes File Does Not Exist");
			
		}
		
		File f = new File(fname+edge);
		if(f.exists()){
			
			Shortest sp = new Shortest();
		
		LinkedHashSet lhs = new LinkedHashSet();
		
		try{
			
			BufferedReader br = new BufferedReader(new FileReader(fname+edge));
			String s = "";
			while((s=br.readLine())!=null){
				
				String s1[] = s.split(" ");
				
				for(int i=0;i<s1.length;i++){
					lhs.add(s1[i]);
				}
				
				int x = Integer.parseInt(s1[2]);
				sp.add(s1[0], s1[1], x);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
				
		
		if(lhs.contains(src)&&lhs.contains(des)){
					
		System.out.println(src+" to "+des);
		List<String> path = sp.gp(src, des);
		
		System.out.println("Number of Nodes:"+lhs1.size());
		System.out.println("Shortest Path:"+path);		
				
		}else{
			
			System.out.println("Please Enter Correct Source and Destination");
			
		}
		
		}else{
			
			System.out.println("Edge File is not Exists.Please Check It");
			
		}

	}

	

}
